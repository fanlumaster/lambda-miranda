||fib n computes the n'th fibonacci number
||by using /count you can estimate the asymptotic limit of (fib n/time to compute fib n)
fib n = 1,                   if n<=2
      = fib(n-1) + fib(n-2), otherwise
